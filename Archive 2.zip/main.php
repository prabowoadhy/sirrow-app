<?php
$_SESSION['username_sirow'];

?>
<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Halaman Administrator </h1>
			</div>
		</div><!--/.row-->

        <div class="row">
			<div class="col-md-12">
				<div class="panel panel-info">
					<div class="panel-heading dark-overlay"><strong>Sistem Informasi Right of Way (SIROW)</strong></div>
					<div class="panel-body">
						<center>
					<img src="images/mitra_logo_new.jpg" alt="" width="400px">
				</center>
          </div>
            </div>
            </div>


	</div>
