<?php
 define('HOST','localhost');
 define('USER','root');
 define('PASS','');
 define('DB','db_dinkes_lapor');

 $con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');
 if($_SERVER['REQUEST_METHOD']=='POST'){
 //Getting values
 $username = $_POST['email'];
 $password = $_POST['password'];

 //Creating sql query
 $sql = "select * from tb_pelapor where username='$username' and password='".md5($password)."'";

 //executing query
 $result = mysqli_query($con,$sql);

 //fetching result
 $check = mysqli_fetch_array($result);

 //if we got some result
 if(isset($check)){
 //displaying success
 echo "success";
 }else{
 //displaying failure
 echo "failure";
 }
 mysqli_close($con);
 }
?>
