function updateMarkerId(title, idlok) {
		document.getElementById('txtId').value = title;
		document.getElementById('txtNama').value = idlok;
	}

function setMarkers(map) {
  var image = {
    url: '../images/fgf.png',
    // This marker is 20 pixels wide by 32 pixels high.
    size: new google.maps.Size(48, 48),
    // The origin for this image is (0, 0).
    origin: new google.maps.Point(0, 0),
    // The anchor for this image is the base of the flagpole at (0, 32).
    anchor: new google.maps.Point(0, 32)
  };
  // Shapes define the clickable region of the icon. The type defines an HTML
  // <area> element 'poly' which traces out a polygon as a series of X,Y points.
  // The final coordinate closes the poly by connecting to the first coordinate.
  
  for (var i = 0; i < beaches.length; i++) {
    var beach = beaches[i];
	var infowindow = null;
	
    var marker = new google.maps.Marker({
      position: {lat: beach[1], lng: beach[2]},
      map: map,
      icon: image,
      title: beach[0],
	  idlok: beach[4],
      zIndex: beach[3]
    	});
	var infowindow = new google.maps.InfoWindow({
		content: beach[0],
	  idlok: beach[4]
		});
		var contentString = "<p>"+this.title+"kete</p>";
		google.maps.event.addListener(marker, 'click', function () {
		// where I have added .html to the marker object.
		//updateMarkerId(this.title, this.idlok);
		infowindow.setContent("<p>"+this.title+"</br>"+this.idlok+"</p>");
		infowindow.open(map, this);
		
		});
		
  }
}