<?php
require_once 'include/DB_Functions.php';
$db = new DB_Functions();

$res = array();
$kode = "";
$pesan = "";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
  $no_wp = $_POST['no_wp'];
  $lokasi = $_POST['lokasi'];
  $pekerjaan = $_POST['pekerjaan'];
  $pengawas = $_POST['pengawas'];
  $pengawask3 = $_POST['pengawask3'];
  $foto = $_FILES['imageupload']['tmp_name'];
  $lat = $_POST['lat'];
  $ln = $_POST['ln'];
  $id_pengawas = $_POST['id_pengawas'];

  $part = "../images_upload/";
  $filename = "img".rand(9,9999).".jpg";

  if ($db->simpan_form($no_wp, $lokasi, $pekerjaan, $pengawas, $pengawask3, $foto, $part, $filename, $lat, $ln, $id_pengawas)) {
    $kode = false;
    $pesan = "berhasil";
  } else {
    $kode = true;
    $pesan = "Muplod gagal";
  }

} else {
  $kode = true;
  $pesan = "Metod tidak vaid";
}

  $res['error'] = $kode;
  $res['message'] = $pesan;

  echo json_encode($res);

 ?>
