<?php
define("DB_HOST", "localhost");
// define("DB_USER", "k424032");
define("DB_USER", "root");
// define("DB_PASSWORD", "8Ge8Fxr5n7");
define("DB_PASSWORD", "");
define("DB_DATABASE", "k4240323_sirrowapp");
?>
