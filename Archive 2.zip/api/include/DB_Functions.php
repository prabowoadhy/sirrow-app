<?php

class DB_Functions {

    private $conn;

    // constructor
    function __construct() {
        require_once 'DB_Connect.php';
        // koneksi ke database
        $db = new Db_Connect();
        $this->conn = $db->connect();
    }

    // destructor
    function __destruct() {

    }
    public function upload_foto($part, $filename){
      $destinationfile = $part.$filename;
      if (move_uploaded_file($foto,$destinationfile)) {
        # code...
        $kode = 1;
        $pesan = "berhasil upload";
        return true;
      } else {
        return false;
      }
    }
    public function simpan_form($no_wp, $lokasi, $pekerjaan, $pengawas, $pengawask3, $foto, $part, $filename, $lat, $ln, $id_pengawas)
    {
      # code...
      $destinationfile = $part.$filename;
      if (move_uploaded_file($foto ,$destinationfile)) {
        # code...
        $stmt = $this->conn->prepare("insert into tb_pekerjaan(no_wp, lokasi, pekerjaan, pengawas_pekerjaan, pengawas_k3, foto, koor_lat, koor_lon, id_pengawas) values (?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param("sssssssss", $no_wp, $lokasi, $pekerjaan, $pengawas, $pengawask3, $filename, $lat, $ln, $id_pengawas);
        $result = $stmt->execute();
        $stmt->close();
        if ($result) {
          # code...
          return true;
        } else {
          return false;
        }

      } else {
        return false;
      }
    }
    public function getList($id_pengawas) {
      # code...
      $stmt = $this->conn->prepare("Select * from tb_pekerjaan where id_pengawas = ? ");

      $stmt->bind_param("s", $id_pengawas);
      if ($stmt->execute()) {
        # code...
        $use1r = $stmt->get_result()->fetch_array();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($user > 0) {
          # code...
          return $user;
        }

      } else {
        return null;
      }
    }
    /**
     * Get user berdasarkan email dan password
     */
    public function getUserByNimAndPassword($username, $password) {

        $stmt = $this->conn->prepare("SELECT * FROM tb_pegawai WHERE user_login = ? and pass_login = MD5(?)");

        $stmt->bind_param("ss", $username, $password);

        if ($stmt->execute()) {
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($user > 0) {
              # code...
              return $user;
            }

            // verifikasi password user
            // $salt = $user['salt'];
            // $encrypted_password = $user['password'];
            // $hash = $this->checkhashSSHA($salt, $password);
            // // cek password jika sesuai
            // if ($encrypted_password == $hash) {
            //     // autentikasi user berhasil
            //     return $user;
            // }
        } else {
            return NULL;
        }
    }

    public function simpanUserMD5($nama, $nim, $password) {

        $stmt = $this->conn->prepare("INSERT INTO tb_mahasiswa(nim, nama_mahasiswa, password, status) VALUES (?, ?, MD5(?), 'aktif')");
        $stmt->bind_param("sss", $nim, $nama, $password);
        $result = $stmt->execute();
        $stmt->close();

        // cek jika sudah sukses
        if ($result) {
            $stmt = $this->conn->prepare("SELECT * FROM tb_mahasiswa WHERE nim = ?");
            $stmt->bind_param("s", $nim);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_array();
            $stmt->close();

            return $user;
        } else {
            return false;
        }
    }
    
    public function updateUser($nama, $id, $password) {
        
        if($password =="") {
            $stmt = $this->conn->prepare("UPDATE tb_pegawai SET nama = ? WHERE id_ = ?");
            $stmt->bind_param("ss", $nama, $id);
        } else {
            $stmt = $this->conn->prepare("UPDATE tb_pegawai SET nama = ?, pass_login = MD5(?) WHERE id_ = ?");
            $stmt->bind_param("sss", $nama, $password, $id);
        }
        
        $result = $stmt->execute();
        $stmt->close();

        // cek jika sudah sukses
        if ($result) {
            $stmt = $this->conn->prepare("SELECT * FROM tb_pegawai WHERE id_ = ?");
            $stmt->bind_param("s", $id);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_array();
            $stmt->close();

            return $user;
        } else {
            return false;
        }
    }

    public function simpanUser($nama, $nim, $password) {
        $uuid = uniqid('', true);
        $hash = $this->hashSSHA($password);
        $encrypted_password = $hash["encrypted"]; // encrypted password
        $salt = $hash["salt"]; // salt

        $stmt = $this->conn->prepare("INSERT INTO tb_mahasiswa(unique_id, nim, nama_mahasiswa, password, salt) VALUES(?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $uuid, $nim, $nama, $encrypted_password, $salt);
        $result = $stmt->execute();
        $stmt->close();

        // cek jika sudah sukses
        if ($result) {
            $stmt = $this->conn->prepare("SELECT * FROM tb_mahasiswa WHERE nim = ?");
            $stmt->bind_param("s", $nim);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            return $user;
        } else {
            return false;
        }
    }



    /**
     * Cek User ada atau tidak
     */
    public function isUserExisted($nim) {
        $stmt = $this->conn->prepare("SELECT nim from tb_mahasiswa WHERE nim = ?");

        $stmt->bind_param("s", $nim);

        $stmt->execute();

        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            // user telah ada
            $stmt->close();
            return true;
        } else {
            // user belum ada
            $stmt->close();
            return false;
        }
    }

    /**
     * Encrypting password
     * @param password
     * returns salt and encrypted password
     */
    public function hashSSHA($password) {

        $salt = sha1(rand());
        $salt = substr($salt, 0, 10);
        $encrypted = base64_encode(sha1($password . $salt, true) . $salt);
        $hash = array("salt" => $salt, "encrypted" => $encrypted);
        return $hash;
    }

    /**
     * Decrypting password
     * @param salt, password
     * returns hash string
     */
    public function checkhashSSHA($salt, $password) {

        $hash = base64_encode(sha1($password . $salt, true) . $salt);

        return $hash;
    }

}

?>
