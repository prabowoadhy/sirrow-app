<?php
require __DIR__ . '/vendor/autoload.php';
require 'libs/NotORM.php';

use \Slim\App;

$app = new App();

$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
// $dbuser = 'k4240323';
// $dbpass = '8Ge8Fxr5n7';
$dbname = 'k4240323_sirrowapp';
$dbmethod = 'mysql:dbname=';

$dsn = $dbmethod.$dbname;
$pdo = new PDO($dsn, $dbuser, $dbpass);
$db = new NotORM($pdo);

$app-> get('/', function(){
    echo "API ";
});
$app ->get('/listpegawai', function() use($app, $db) {
  $dosen["error"] = false;
  $dosen["message"] = "berhasil mendapatkan data pegawai";
  foreach ($db->tb_pegawai() as $data) {
    # code...
    $dosen['listpegawai'][] = array(
      'nama'=>$data['nama']
    );
  }
  echo json_encode($dosen);
});

$app->get('/list/{pengawas}', function($request, $response, $args) use($app, $db){
  $stmt = $db->tb_pekerjaan()->where('id_pengawas', $args['pengawas']);
  // $stmt = $this->db->prepare($sql);
  $list = $stmt->fetch();
  // return $response->withJson(["status" => "success", "data" => $list], 200);
  // $listhistori2 = $list->fetch();
  if ($list->count()==0) {
    # code...
    $responseJson["error"]=true;
    $responseJson["message"]="Belum Melakukan pekerjaan";
    $responseJson["id_"] = null;
    $responseJson["no_wp"] = null;
    $responseJson["lokasi"] = null;
    $responseJson["pekerjaan"] = null;
    $responseJson["pengawas_pekerjaan"] = null;
    $responseJson["pengawas_k3"] = null;
    $responseJson["tanggal"] = null;
    $responseJson["foto"] = null;
    $responseJson["koor_lat"] = null;
    $responseJson["koor_lon"] = null;
  } else {
    $responseJson["error"] = false;
    $responseJson["message"] = "Berhasil mengambil Data";
    foreach ($stmt as $listhistori) {
      # code...
      $responseJson['semualist'][] = array("id_" => $listhistori["id_"],
      "no_wp" => $listhistori["no_wp"],
      "lokasi" => $listhistori["lokasi"],
      "pekerjaan" => $listhistori["pekerjaan"],
      "pengawas_pekerjaan" => $listhistori["pengawas_pekerjaan"],
      "pengawas_k3" => $listhistori["pengawas_k3"],
      "tanggal" => $listhistori["tanggal"],
      "foto" => $listhistori["foto"],
      "koor_lat" => $listhistori["koor_lat"],
      "koor_lon"=> $listhistori["koor_lon"]);
  }
  }
  echo json_encode($responseJson);
});

$app->post('/addpekerja', function($request, $response, $args) use($app, $db) {
  $pekerja = $request->getParams();
  $result = $db->tb_wp_pekerja->insert($pekerja);
  if ($result) {
    # code...

  $responseJson["error"] = false;
  $responseJson["message"] = "berhasil menambahkan";
} else {
  $responseJson["error"] = true;
  $responseJson["message"] = "gagal menambahkan";
}
  echo json_encode($responseJson);
});


//run App
$app->run();
