<?php

echo "username : adip<br>";
echo "pass = prabowo<br>";
$password = "sOyKXdxEiJBEuoRpwuxPhcPaRb8wZGEyNzQ0ZjY";
$salt = "0da2744f60";
echo "password = ".$password."<br>salt = ".$salt."<br>";
$hash = base64_encode(sha1($password . $salt, true) . $salt);
echo $hash;

$salt1 = sha1(rand());
$salt1 = substr($salt1, 0, 10);
echo "<br>".$salt1;


// $uuid = uniqid('', true);
// $hash = hashSSHA($password);
// $encrypted_password = $hash["encrypted"]; // encrypted password
// $salt = $hash["salt"]; // salt
//
// echo "UUID = ".$uuid."<br>password = ".$encrypted_password."<br>salt = ".$salt;
// $stmt = $this->conn->prepare("INSERT INTO tb_mahasiswa(unique_id, nim, nama_mahasiswa, password, salt) VALUES(?, ?, ?, ?, ?)");
// $stmt->bind_param("sssss", $uuid, $nim, $nama, $encrypted_password, $salt);
// $result = $stmt->execute();
// $stmt->close();

// cek jika sudah sukses
// if ($result) {
    // $stmt = $this->conn->prepare("SELECT * FROM tb_mahasiswa WHERE nim = ?");
    // $stmt->bind_param("s", $nim);
    // $stmt->execute();
    // $user = $stmt->get_result()->fetch_assoc();
    // $stmt->close();

    // return $user;
// } else {
    // return false;
// }




 ?>
