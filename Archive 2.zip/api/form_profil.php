<?php

require_once 'include/DB_Functions.php';
$db = new DB_Functions();

// json response array
$response = array("error" => FALSE);

if (isset($_POST['nama']) && isset($_POST['id']) && isset($_POST['password'])) {

    // menerima parameter POST ( nama, nim, password )
    $nama = $_POST['nama'];
    $id = $_POST['id'];
    $password = $_POST['password'];
    
        // buat user baru
        $user = $db->updateUser($nama, $id, $password);
        if ($user) {
            // simpan user berhasil
            $response["error"] = FALSE;
            $response["user"]["nama"] = $user["nama"];
            $response["user"]["id"] = $user["id_"];
            echo json_encode($response);
        } else {
            // gagal menyimpan user
            $response["error"] = TRUE;
            $response["message"] = "Terjadi kesalahan saat melakukan ubahan";
            echo json_encode($response);
        }
    
} else {
    $response["error"] = TRUE;
    $response["message"] = "Parameter (nama, nim, atau password) ada yang kurang";
    echo json_encode($response);
}
?>
