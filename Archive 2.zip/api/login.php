<?php
require_once 'include/DB_Functions.php';
$db = new DB_Functions();

// json response array
$response = array("error" => FALSE);

if (isset($_POST['username']) && isset($_POST['password'])) {

    // menerima parameter POST ( email dan password )
    $username = $_POST['username'];
    $password = $_POST['password'];

    // get the user by email and password
    // get user berdasarkan email dan password
    $user = $db->getUserByNimAndPassword($username, $password);

    if ($user != false) {
        // user ditemukan
        $response["error"] = FALSE;
        $response["user"]["nama"] = $user["nama"];
        $response["user"]["jabatan"] = $user["jabatan"];
        $response["user"]["id"] = $user["id_"];
        $response["user"]["username"] = $user["user_login"];
        echo json_encode($response);
    } else {
        // user tidak ditemukan password/email salah
        $response["error"] = TRUE;
        $response["error_msg"] = "Login gagal. Password/Username salah";
        echo json_encode($response);
    }
} else {
    $response["error"] = TRUE;
    $response["error_msg"] = "Parameter (Username atau password) ada yang kurang";
    echo json_encode($response);
}
?>
