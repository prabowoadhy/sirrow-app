<?php
require_once 'include/DB_Functions.php';
$db = new DB_Functions();

$res = array();
$kode = "";
$pesan = "";

$pengawas = $_GET['pengawas'];
$list = $db->getList($pengawas);
if ($list) {
  # code...
  foreach ($list as $key) {
    # code...

    $lis['semua'][] = array(
    'no_wp' => $key['no_wp'],
    'tanggal' => $key["tanggal"],
    "lokasi"=> $key["lokasi"],
    "pekerjaan"=> $key["pekerjaan"],
    "pengawas" => $key["pengawas_pekerjaan"],
    "pengawask3" => $key["pengawas_k3"],
    "foto" => $key["foto"],
    "koor_lat"=> $key["koor_lat"],
    "koor_lon" => $key["koor_lon"]);
  }

  echo json_encode($lis);
}
// echo $pengawas;
 ?>
