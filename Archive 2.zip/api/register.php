<?php

require_once 'include/DB_Functions.php';
$db = new DB_Functions();

// json response array
$response = array("error" => FALSE);

if (isset($_POST['nama']) && isset($_POST['nim']) && isset($_POST['password'])) {

    // menerima parameter POST ( nama, nim, password )
    $nama = $_POST['nama'];
    $nim = $_POST['nim'];
    $password = $_POST['password'];

    // Cek jika user ada dengan nim yang sama
    if ($db->isUserExisted($nim)) {
        // user telah ada
        $response["error"] = TRUE;
        $response["error_msg"] = "User telah ada dengan NIm " . $nim;
        echo json_encode($response);
    } else {
        // buat user baru
        $user = $db->simpanUserMD5($nama, $nim, $password);
        if ($user) {
            // simpan user berhasil
            $response["error"] = FALSE;
            $response["user"]["nama"] = $user["nama_mahasiswa"];
            $response["user"]["nim"] = $user["nim"];
            echo json_encode($response);
        } else {
            // gagal menyimpan user
            $response["error"] = TRUE;
            $response["error_msg"] = "Terjadi kesalahan saat melakukan registrasi";
            echo json_encode($response);
        }
    }
} else {
    $response["error"] = TRUE;
    $response["error_msg"] = "Parameter (nama, nim, atau password) ada yang kurang";
    echo json_encode($response);
}
?>
