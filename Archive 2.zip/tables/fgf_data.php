<?php
include_once "../library/inc.connection.php";

$query = "SELECT * from tb_lokasifgf ";
$result = mysql_query($query) or die(mysql_error());
 
$arr = array();
while ($row = mysql_fetch_assoc($result)) {
    $temp = array(
  "idLokasi" => $row["idLokasi"],
    "nama" => $row["nama"],
    "lat" => $row["lat"], 
    "lng" => $row["lng"], 
    "area" => $row["area"],
	"keterangan" => $row["keterangan"],
	"aksi" => "<a href='?open=FGF-Edit&amp;ID=".$row["idLokasi"]."'><svg class='glyph stroked pencil' style='height:16px; width:16px;'><use xlink:href='#stroked-pencil'/></svg>|<a href='?open=FGF-Delete&amp;Kode=".$row["idLokasi"]."' onclick='return confirm('Are you sure?');'><svg class='glyph stroked trash' style='height:16px; width:16px;'><use xlink:href='#stroked-trash'></use></svg></a>");
   
    array_push($arr, $temp);
}
 
$data = json_encode($arr);
 
echo  $data ;
?>