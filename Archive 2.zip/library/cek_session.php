<?php
 session_start();
 //mengecek apakah session username kosong atau tidak
 if (!isset($_SESSION['username_sirow']) || empty($_SESSION['username_sirow'])) {
  //jika kosong redirect ke halaman login
  header('location:login.php');
 } else {
 }
?>
