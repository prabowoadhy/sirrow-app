<?php
$myHost = "localhost";
// $myUser = "k4240323";
// $myPass = "8Ge8Fxr5n7";
$myUser = "root";
$myPass = "";
$myDbs = "k4240323_sirrowapp";

$koneksidb = mysqli_connect ($myHost, $myUser, $myPass, $myDbs);

?>
