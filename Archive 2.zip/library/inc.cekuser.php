<?php
$user = $_SESSION['username_sirow'];
$myuserSql = "SELECT * from tb_pegawai where user_login = '$user'";
$myuserQry = mysqli_query($koneksidb, $myuserSql) or die ("error Query".mysqli_error($koneksidb));
$myUser = mysqli_fetch_array($myuserQry);
?>
