-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: 11 Apr 2018 pada 03.47
-- Versi Server: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_sirow`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pegawai`
--

CREATE TABLE `tb_pegawai` (
  `id_` int(11) NOT NULL,
  `nip` varchar(15) NOT NULL,
  `nama` varchar(25) NOT NULL,
  `jabatan` varchar(15) NOT NULL,
  `user_login` varchar(8) NOT NULL,
  `pass_login` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_pegawai`
--

INSERT INTO `tb_pegawai` (`id_`, `nip`, `nama`, `jabatan`, `user_login`, `pass_login`) VALUES
(1, '1221108', 'Tri Adhy Prabowo', 'pengawas', 'adip', 'b504301092fbfe21c6a27f88768443bd');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pekerjaan`
--

CREATE TABLE `tb_pekerjaan` (
  `id_` int(11) NOT NULL,
  `no_wp` varchar(15) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `pekerjaan` varchar(25) NOT NULL,
  `lokasi` varchar(50) NOT NULL,
  `pengawas_pekerjaan` varchar(50) NOT NULL,
  `pengawas_k3` varchar(50) NOT NULL,
  `foto` varchar(50) NOT NULL,
  `koor_lat` varchar(50) NOT NULL,
  `koor_lon` varchar(50) NOT NULL,
  `id_pengawas` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_pekerjaan`
--

INSERT INTO `tb_pekerjaan` (`id_`, `no_wp`, `tanggal`, `pekerjaan`, `lokasi`, `pengawas_pekerjaan`, `pengawas_k3`, `foto`, `koor_lat`, `koor_lon`, `id_pengawas`) VALUES
(1, 'wp0001', '2018-04-06 13:19:35', 'Rabas - Rabas', 'joraying', 'Tri Adhy Prabowo', 'adip', 'img2376.jpg', '1221120', '1313130000', '1'),
(2, 'wp002', '2018-04-06 13:21:42', 'Pengawasan AC', 'jjj', 'Tri Adhy Prabowo', 'susilo', 'img2845.jpg', '1221120', '1313130000', '1'),
(3, '333', '2018-04-06 13:43:29', 'Rabas - Rabas', 'fff', 'Tri Adhy Prabowo', 'hhhq', 'img24.jpg', '1221120', '1313130000', '1'),
(4, '1', '2018-04-06 14:20:56', 'Rabas - Rabas', '1', 'Tri Adhy Prabowo', '1', 'img7359.jpg', '1221120', '1313130000', '1'),
(5, '111', '2018-04-06 14:38:03', 'Pengawasan AC', 'qq', 'Tri Adhy Prabowo', 'qqq', 'img715.jpg', '1221120', '1313130000', '1'),
(6, 'sas', '2018-04-10 04:32:54', 'Rabas - Rabas', 'asas', 'Tri Adhy Prabowo', 'asas', 'img1979.jpg', '-7.6299754', '111.4930317', '1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_wp_pekerja`
--

CREATE TABLE `tb_wp_pekerja` (
  `id_` int(11) NOT NULL,
  `no_wp` varchar(15) NOT NULL,
  `nama_pekerja` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_wp_pekerja`
--

INSERT INTO `tb_wp_pekerja` (`id_`, `no_wp`, `nama_pekerja`) VALUES
(1, 'wp002', 'Agus'),
(2, 'wp002', 'Wahyu'),
(3, 'wp002', 'Susi'),
(4, '333', 'tri'),
(5, '333', 'adip'),
(6, '1', 'sasa'),
(7, '1', 'sasa'),
(8, '111', ''),
(9, '111', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_pegawai`
--
ALTER TABLE `tb_pegawai`
  ADD PRIMARY KEY (`id_`);

--
-- Indexes for table `tb_pekerjaan`
--
ALTER TABLE `tb_pekerjaan`
  ADD PRIMARY KEY (`id_`);

--
-- Indexes for table `tb_wp_pekerja`
--
ALTER TABLE `tb_wp_pekerja`
  ADD PRIMARY KEY (`id_`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_pegawai`
--
ALTER TABLE `tb_pegawai`
  MODIFY `id_` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tb_pekerjaan`
--
ALTER TABLE `tb_pekerjaan`
  MODIFY `id_` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tb_wp_pekerja`
--
ALTER TABLE `tb_wp_pekerja`
  MODIFY `id_` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
